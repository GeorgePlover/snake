#include "Game.h"
#include <iostream>
using namespace sfSnake;

int main()
{
	Game game;
    //std::cout<<game.window_pos().x<<" "<<game.window_pos().y<<std::endl;
	game.run();

	return 0;
}
